var api = window.location.protocol + "//" + window.location.host;
